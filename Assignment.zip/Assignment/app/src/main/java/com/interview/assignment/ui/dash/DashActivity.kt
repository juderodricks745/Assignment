package com.interview.assignment.ui.dash

import android.os.Bundle
import com.interview.assignment.R
import android.support.v7.app.AppCompatActivity

class DashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash)


    }
}
