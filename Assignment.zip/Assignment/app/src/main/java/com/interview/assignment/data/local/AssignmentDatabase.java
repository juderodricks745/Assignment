package com.interview.assignment.data.local;

public abstract class AssignmentDatabase {
}
