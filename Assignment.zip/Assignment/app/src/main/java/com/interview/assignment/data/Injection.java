package com.interview.assignment.data;

public class Injection {


}
